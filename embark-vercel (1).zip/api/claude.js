// api/claude.js
// Secure server-side proxy to the Anthropic API.
// The API key lives ONLY here (read from an environment variable on Vercel),
// never in the browser. The front-end calls this endpoint instead of calling
// Anthropic directly.
//
// Vercel exposes this automatically at:  https://<your-app>.vercel.app/api/claude

export default async function handler(req, res) {
  // Only accept POST from the app.
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed. Use POST." });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // Clear, actionable error in the interface's voice — not a stack trace.
    res.status(500).json({
      error:
        "The tutor isn't configured yet. Add ANTHROPIC_API_KEY in your Vercel project settings, then redeploy.",
    });
    return;
  }

  try {
    const { system, messages, max_tokens } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: "Missing messages." });
      return;
    }

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: Math.min(max_tokens || 1000, 1500),
        system: system || undefined,
        messages,
      }),
    });

    const data = await anthropicRes.json();

    if (!anthropicRes.ok) {
      // Surface Anthropic's own message but keep it brief.
      const msg =
        (data && data.error && data.error.message) ||
        "The tutor couldn't be reached. Try again in a moment.";
      res.status(anthropicRes.status).json({ error: msg });
      return;
    }

    // Pass the successful response straight through.
    res.status(200).json(data);
  } catch (err) {
    res
      .status(502)
      .json({ error: "The tutor couldn't be reached. Try again in a moment." });
  }
}
